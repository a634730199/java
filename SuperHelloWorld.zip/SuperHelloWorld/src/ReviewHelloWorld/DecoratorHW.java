package ReviewHelloWorld;

public class DecoratorHW extends ImplementsAbstractHW{

	public DecoratorHW(InterfaceHW HW) {
		this.HW = HW;
	}

	@Override
	public String showHW() {
		return "Hello World";
	}
	
}
