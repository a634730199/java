package ReviewHelloWorld;

public class ExtendsHW extends ImplementsAbstractHW{

	public ExtendsHW(InterfaceHW HW) {
		this.HW = HW;
	}

	@Override
	public String showHW() {
		return "Hello World";
	}
	

	
	
}
