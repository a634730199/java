package ReviewHelloWorld;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");  
		
		String hw;
		hw = "Hello World";
		System.out.println(hw);             
		
		String[] str1 = new String[11];
		int i = 0;
		do {
			switch(i) {
			case 0:
				str1[i] = "d";
				break;
			case 1:
				str1[i] = "l";	
				break;
			case 2:
				str1[i] = "r";	
				break;
			case 3:
				str1[i] = "o";	
				break;
			case 4:
				str1[i] = "W";
				break;
			case 5:
				str1[i] = " ";	
				break;
			case 6:
				str1[i] = "o";	
				break;
			case 7:
				str1[i] = "l";
				break;
			case 8:
				str1[i] = "l";
				break;
			case 9:
				str1[i] = "e";	
				break;
			case 10:
				str1[i] = "H";
				break;
			default :
				System.out.print("Hello World");
				break;
			}
			i++;
		}while(i < str1.length);
		i-=1;
		while(i >= 0) {
			System.out.print(str1[i]);                
			i--;
		}
		System.out.println();
		
		String str2 = null;
		for(i = 0; i < 1;i++) {
			str2 =  i == 0 ? "Hello World" : "Hello World";          
		}
		System.out.println(str2);                     
		
		String[][] str3 = new String[2][11];
		for (int j = 0; j < 2; j++) {
			for (i = 0; i < 11; i++) {
				str3[j][i] = str1[10-i];
			}
		}
		
		for (int j = 0; j < 2; j++) {
			for (i = 0; i < 11; i++) {
				System.out.print(str3[j][i]);
			}
			System.out.println();
		}
		

		InterfaceHW hw1 = null;
		hw1 = new DecoratorHW(hw1);
		System.out.println(hw1.showHW());                              
		
		InterfaceHW hw2 = null;
		hw2 = new ExtendsHW(hw2);
		System.out.println(hw2.showHW());                               
		
		
		//arraylist
		List<String> list = new ArrayList<>();
		list.add("Hello World"); 
		
		//set
		Set<String> set = new HashSet<>();
		set.addAll(list);
		
		//linkedlist
		List<String> linkList = new LinkedList<String>();
		linkList.addAll(list);

		//foreach����
		linkList.forEach(str4 -> System.out.println(str4));            
		
		//����������
		Iterator<String> listIt = list.iterator();
		while(listIt.hasNext()) {
			System.out.println(listIt.next());                         
		}

		for(String str5 : set) {
			System.out.println(str5);                                  
		}
		
		StringBuffer str6 = new StringBuffer();
		str6.append("Hello World" + "\n");
		str6.append(hw1.showHW() + "\n").append(hw2.showHW() + "\n").append(hw);
		System.out.println(str6.toString());
		
		
		//����
		for (int j = 0; j < str1.length; j++) {
			list.add(str1[j]);
		}
		Collections.reverse(list);
		for (int j = 0; j < str1.length; j++) {
			str1[j] = list.get(j);
		}
		
		for (int j = 0; j < str1.length; j++) {
			System.out.print(str1[j]);
		}
		
		
	
	}

}
