package ReviewHelloWorld;

public abstract class ImplementsAbstractHW implements InterfaceHW{
	InterfaceHW HW;
	@Override
	public String showHW() {
		return "Hello World";
	}
	
}
