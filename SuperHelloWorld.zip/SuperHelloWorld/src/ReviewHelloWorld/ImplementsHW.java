package ReviewHelloWorld;

public abstract class ImplementsHW implements InterfaceHW{

	String HW;
	@Override
	public abstract String showHW();
	
}
