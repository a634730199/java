package ReviewHelloWorld;

public interface InterfaceHW {
	String showHW();
}
