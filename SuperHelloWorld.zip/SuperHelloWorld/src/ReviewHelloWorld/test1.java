package ReviewHelloWorld;

public class test1 {

	public static void main(String[] args) {
		String[] str1 = new String[11];
		int i = 0;
		do {
			switch(i) {
			case 0:
				str1[i] = "d";
				break;
			case 1:
				str1[i] = "l";	
				break;
			case 2:
				str1[i] = "r";	
				break;
			case 3:
				str1[i] = "o";	
				break;
			case 4:
				str1[i] = "W";
				break;
			case 5:
				str1[i] = " ";	
				break;
			case 6:
				str1[i] = "o";	
				break;
			case 7:
				str1[i] = "l";
				break;
			case 8:
				str1[i] = "l";
				break;
			case 9:
				str1[i] = "e";	
				break;
			case 10:
				str1[i] = "H";
				break;
			default :
				System.out.print("Hello World");
				break;
			}
			i++;
		}while(i < str1.length);
		i-=1;
		while(i >= 0) {
			System.out.print(str1[i]);                //  3
			i--;
		}
		System.out.println();
		System.out.println(str1.length);
		
		String[][] str5 = new String[2][11];
		for (int j = 0; j < 2; j++) {
			for (i = 0; i < 11; i++) {
				str5[j][i] = str1[10-i];
			}
		}
		
		for (int j = 0; j < 2; j++) {
			for (i = 0; i < 11; i++) {
				System.out.print(str5[j][i]);
			}
			System.out.println();
		}
	}

}
